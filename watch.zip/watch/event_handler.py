from menus import MenuOptions

class EventHandler():
    def __init__(self):
        self.mo = MenuOptions()

    def getMainMenu(self):
        return self.mo.mainMenu

    def getMenuList(self, menu):
        return self.mo.getMenuOpts(menu)

    def getMainMenuList(self):
        return self.mo.getMenuOpts(self.mo.mainMenu)

    def parseEvent(self, event):
        print("Parsing {}".format(event))
        if isinstance(event, dict):
            return self.getMenu(event)
        else:
            return self.getEvent(event)

    def getEvent(self, event):
        print("Get Event {}".format(event))
        if event == 'goBack':
            menuList = self.mo.getMenuOpts(self.mo.mainMenu)
            return menuList
        else:
            menuList = self.mo.getMenuOpts(self.mo.soundMenu)
            return menuList

    def getMenu(self, event):
        menuList = self.mo.getMenuOpts(event)
        return menuList
