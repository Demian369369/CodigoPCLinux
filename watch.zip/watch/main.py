#import boot as b
#b.button()
import sh1106
from machine import Pin, I2C
import time
i2c = I2C(scl=Pin(4), sda=Pin(5), freq=400000)
display = sh1106.SH1106_I2C(128, 64, i2c, None, 0x3c)
display.sleep(False)
display.rotate(True,update=True)

#display.fill(0)
#display.text('Testing 1', 0, 20, 1)
#display.show()
flag = 0
class tiempo:
    def __init__(self):
        self.año = 0
        self.mes = 0
        self.dia = 0
        self.hora = 0
        self.minuto = 0
        self.segundo = 0
    def imprimeHora(self):
        tiempo = str(contador.hora) + ":" + str(contador.minuto) + ":"+ str(contador.segundo)
        return tiempo
    def imprimeFecha(self):
        fecha = str(contador.año) + " | " + str(contador.mes) + " | " + str(contador.dia) 
        return fecha
    def elTiempo(self):
        if self.segundo <= 59:
            self.segundo += 1
        elif self.minuto <= 59:
            self.minuto += 1
            self.segundo = 0
        elif self.hora <= 23 and self.minuto == 60:
            self.hora += 1
            self.minuto = 0
            self.segundo = 0
        elif self.dia <= 30 and self.hora == 24:
            self.dia += 1
            self.hora = 0
            self.minuto = 0
            self.segundo = 0
        elif self.mes <= 11 and self.dia == 30:
            self.mes += 1
            self.dia = 0
            self.hora = 0
            self.minuto = 0
            self.segundo = 0
        elif self.año <= 100 and self.mes == 12:
            self.año += 1
            self.mes = 0
            self.dia = 0
            self.hora = 0
            self.minuto = 0
            self.segundo = 0
        #if hora >= 11:
         #   display.text('PM', 30, 12, 1)
        #else:
          #  display.text('AM', 30, 12, 1)
contador = tiempo()
while True:
    display.fill(0)
    contador.elTiempo()
    tiempo = contador.imprimeHora()
    fecha = contador.imprimeFecha()
    display.text('Tiempo: ', 20, 10, 1)
    display.text(tiempo, 20, 20, 1)
    display.text('Fecha: ', 20, 30, 1)
    display.text(fecha, 20, 40, 1)
    #display.line(0, 0, flag, 64, 1)
    flag = flag + 1
    time.sleep(1)
    display.show()
    